const ApiList = {
    Characters : `characters`
}

export default ApiList